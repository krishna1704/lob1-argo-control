# Introduction
This repository aks addons "calico-global-policies" details.


## Usage



### Permissions Boundary


## Resources
This repository creates aks addons "calico-global-policies" 

## Authors

Module is maintained by "Cloud 3.0 Core Networking & Platform team"
